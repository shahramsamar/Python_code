import csv
from statistics import mean

def calculate_averages(input_file_name, output_file_name):
 with open(input_file_name,'r') as csvfile :
  reader = csv.reader(csvfile)
  with open(output_file_name,'w',newline = '') as outfile :
         writer = csv.writer(outfile)
         for row in reader :
          ##print(row)
          greade_mean = (float(infile) for infile in row[1:])
          writer.writerow([row[0],mean(greade_mean)])

def calculate_sorted_averages(input_file_name, output_file_name):
 dict= {}     
 with open(input_file_name,'r') as csvfile :
     reader = csv.reader(csvfile)
     with open(output_file_name,'w',newline = '') as sortfile :
         writer = csv.writer(sortfile)
         for row in reader :
           ##print(row)
           score = []
           for i in range(1,len(row)) :
              score.append(float(row[i]))
              avg = mean(score)
           dict[row[0]] = avg 
          ## print(dict)
         dict = sorted(dict.items(),key = lambda x:(x[1],x[0]))
         for person in dict:
           ##print(person[0],person[1])
            writer.writerow([person[0],person[1]])

def calculate_three_best(input_file_name, output_file_name):
 dict= {}     
 with open(input_file_name,'r') as csvfile :
     reader = csv.reader(csvfile)
     with open(output_file_name,'w',newline = '') as three_best :
         writer = csv.writer(three_best)
         for row in reader :
             ##print(row[0],row[1])
           score = []
           for i in range(1,len(row)) :
              score.append(float(row[i]))
              avg = mean(score)
            ##   print('avg',avg)   
           dict[row[0]] = avg 
        ## print(dict)
         dict = sorted(dict.items(),key = lambda x:(x[1],x[0]))
         for  i in range(3):
          three_best =dict.pop()
          ##print(three_best[0],three_best[1])
          writer.writerow([three_best[0],three_best[1]])

def calculate_three_worst(input_file_name, output_file_name):
 dict= {}     
 with open(input_file_name,'r') as csvfile :
     reader = csv.reader(csvfile)
     with open(output_file_name,'w',newline = '') as three_worst :
         writer = csv.writer(three_worst)
         for row in reader :
             ##print(row[0],row[1])
           score = []
           for i in range(1,len(row)) :
              score.append(float(row[i]))
              avg = mean(score)
             ##   print('avg',avg)   
           dict[row[0]] = avg 
         ##print(dict)
         dict = sorted(dict.items(),key = lambda x:(x[1],x[0]))
         writer.writerow([dict[0][1]])
         writer.writerow([dict[1][1]])
         writer.writerow([dict[2][1]])

def calculate_average_of_averages(input_file_name, output_file_name):
 dict= {}     
 with open(input_file_name,'r') as csvfile :
     reader = csv.reader(csvfile)
     with open(output_file_name,'w',newline = '') as average_of_averages :
         writer = csv.writer(average_of_averages)
         for row in reader :
           ##print(row)
           score = []
           for i in range(1,len(row)) :
              score.append(float(row[i]))
              avg = mean(score)
           dict[row[0]] = avg 
           ##print(dict)
         dict = sorted(dict.items(),key = lambda x:(x[1],x[0]))
         #print(dict)
         sum = []
         for average in dict:
            sum.append((average[1]))
            count = 0
         for i in sum:
              count += i
              #print(i)
         writer.writerow([count /len(sum)])     
         #print(count /len(sum))

# calculate_averages(csv,csv)  
# calculate_sorted_averages(csv,csv)
# calculate_three_best(csv,csv)
# calculate_three_worst(csv,csv)
# calculate_average_of_averages(csv,csv)
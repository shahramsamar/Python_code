from hashlib import sha256
import hashlib 
import csv

def hash_password_hack(input_file_name, output_file_name):
  with open(input_file_name,'r')  as haschfile :
     reader = csv.reader(haschfile)
     hash = {}
     new_hash = {}
     for i in range (1000,10000):
           #print(i)
          sha256hash = hashlib.sha256((str(i).encode('utf-8'))).hexdigest()
          hash[sha256hash] = i
          #create hash
         #  print(sha256hash)
          #create keys()
         #  print(hash[sha256hash])
         #print(hash)

         #master file
     for r in reader :
        name = r[0]
        hash_in_r = r[1]  
        #print(r[0],",",r[1])

        #find hash & find pass
        for hash_in_hash in hash.keys() :
         #   print(hash_in_hash)
           if hash_in_r == hash_in_hash :
              new_hash[name] = hash.get(hash_in_hash)
            #   print(new_hash) 

     with open(output_file_name,'w',newline='') as final :
         writer = csv.writer(final)
         for name in new_hash:
          writer.writerow([name,str(new_hash [name])])

#hash_password_hack(csv,csv)

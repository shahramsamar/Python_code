import random 
list = ['Akbar', 'Nima', 'Amin', 'Milad', 'shahrooz', 'Behzad', 'Farhad', 'Maziar', 'Mostafa', 'Khashayar', 'Pouya',
        'Pouria', 'Reza', 'Soheil', 'Ali', 'Mahdi', 'Mohsen', 'Behrooz', 'Said', 'Mohammad', 'Hossein', 'Saman']
# print(list)
class human :
    def __init__(self,name) :
          self.name = name
    
    def get_name(self) :
         print(self.name)

# A  = human('shahram')
# A.get_name()

class soccerـplayer(human) :
    pass
    def get_team_A() :
         team_A = []
         for num,names in enumerate(list) :
            #  print(num,names)
             team = random.choice(list)
             list.pop(num)
            #  print('nume :',num,'names:',names)
             team_A.append(team)
        #  print('team_A:',team_A)
         for player in team_A :
              print(f"{player}-{'team_A'}")
# # print(team_A)
# # print(list)
    def get_team_B() :
         team_B = []
         for num,names in enumerate(list) :
            #  print(num,names)
             team = random.choice(list)
            #  print('nume :',num,'names:',names)
             team_B.append(team)
        #  print('team_B:',team_B)
         for player in team_B :
              print(f"{player}-{'team_B'}")


team_A = soccerـplayer
team_B =soccerـplayer
team_A.get_team_A()
team_B.get_team_B()




import random
a_1=1
b_1=99
hads=random.randint(a_1,b_1)
print(hads)
javab=input()
while javab!='d':
    if javab=='b':
        a_1=hads
        b_1=99
        hads=random.randint(a_1,b_1)
        print(hads)
        print('bozorgtar')
        javab=input()
    elif javab=='k':
        b_1=hads
        hads=random.randint(a_1,b_1)
        print(hads)
        print('kochiktar')
        javab=input()
print ('oh doroste you hoooooooo afrin pesar')        